<?php


require_once("pages/system/seguranca.php");
require_once("pages/system/config.php");
require_once("pages/system/classe.ssh.php");



protegePagina("user");

// pegando ip do usuario

$ipusuario = pega_ip();
echo $ipusuario;



    




$quantidade_ssh = 0;
$quantidade_ssh_user = 0;
$quantidade_ssh_sub = 0;
$quantidade_sub = 0;
$all_ssh_susp_qtd = 0;

$SQLUsuario = "SELECT * FROM usuario WHERE id_usuario = '" . $_SESSION['usuarioID'] . "'";
$SQLUsuario = $conn->prepare($SQLUsuario);
$SQLUsuario->execute();
$usuario = $SQLUsuario->fetch();
// avatares
switch ($usuario['avatar']) {
    case 1:
        $avatarusu = "avatar1.png";
        break;
    case 2:
        $avatarusu = "avatar2.png";
        break;
    case 3:
        $avatarusu = "avatar3.png";
        break;
    case 4:
        $avatarusu = "avatar4.png";
        break;
    case 5:
        $avatarusu = "avatar5.png";
        break;
    default:
        $avatarusu = "boxed-bg.png";
        break;
}


if ($usuario['tipo'] == 'revenda') {
    $tipouser = 'Revendedor';
} elseif ($usuario['tipo'] == 'vpn') {
    $tipouser = 'Usuário VPN';
}

$datacad = $usuario['data_cadastro'];

$partes = explode("-", $datacad);
$ano = $partes[0];
$mes = $partes[1];

$Mes = muda_mes($mes);
$Meses = muda_mes2($mes);



$SQLUsuario_ssh = "select * from usuario_ssh WHERE id_usuario = '" . $_SESSION['usuarioID'] . "' ";
$SQLUsuario_ssh = $conn->prepare($SQLUsuario_ssh);
$SQLUsuario_ssh->execute();
$quantidade_ssh += $SQLUsuario_ssh->rowCount();

$SQLUsuario_sshSUSP = "select * from usuario_ssh WHERE id_usuario = '" . $_SESSION['usuarioID'] . "' and  status='2' and apagar='0' ";
$SQLUsuario_sshSUSP = $conn->prepare($SQLUsuario_sshSUSP);
$SQLUsuario_sshSUSP->execute();
$all_ssh_susp_qtd += $SQLUsuario_sshSUSP->rowCount();

$total_acesso_ssh = 0;
$SQLAcessoSSH = "SELECT sum(acesso) AS quantidade  FROM usuario_ssh where id_usuario='" . $_SESSION['usuarioID'] . "' ";
$SQLAcessoSSH = $conn->prepare($SQLAcessoSSH);
$SQLAcessoSSH->execute();
$SQLAcessoSSH = $SQLAcessoSSH->fetch();
$total_acesso_ssh += $SQLAcessoSSH['quantidade'];

$total_acesso_ssh_online = 0;
$SQLAcessoSSH = "SELECT sum(online) AS quantidade  FROM usuario_ssh  where id_usuario='" . $_SESSION['usuarioID'] . "' ";
$SQLAcessoSSH = $conn->prepare($SQLAcessoSSH);
$SQLAcessoSSH->execute();
$SQLAcessoSSH = $SQLAcessoSSH->fetch();
$total_acesso_ssh_online += $SQLAcessoSSH['quantidade'];




$SQLAcesso = "select * from acesso_servidor WHERE id_usuario = '" . $_SESSION['usuarioID'] . "' ";
$SQLAcesso = $conn->prepare($SQLAcesso);
$SQLAcesso->execute();
$acesso_servidor = $SQLAcesso->rowCount();


//Arquivos download
$SQLArquivos = "select * from  arquivo_download";
$SQLArquivos = $conn->prepare($SQLArquivos);
$SQLArquivos->execute();
$todosarquivos = $SQLArquivos->rowCount();
if ($usuario['id_mestre'] == 0) {
    // Faturas
    $SQLfaturas = "select * from  fatura where status='pendente' and usuario_id='" . $_SESSION['usuarioID'] . "'";
    $SQLfaturas = $conn->prepare($SQLfaturas);
    $SQLfaturas->execute();
    $faturas = $SQLfaturas->rowCount();
} else {
    // Faturas
    $SQLfaturas = "select * from  fatura_clientes where status='pendente' and usuario_id='" . $_SESSION['usuarioID'] . "'";
    $SQLfaturas = $conn->prepare($SQLfaturas);
    $SQLfaturas->execute();
    $faturas = $SQLfaturas->rowCount();
}
if ($usuario['tipo'] == 'revenda') {
    // Faturas
    $SQLfaturas2 = "select * from  fatura_clientes where status='pendente' and id_mestre='" . $_SESSION['usuarioID'] . "'";
    $SQLfaturas2 = $conn->prepare($SQLfaturas2);
    $SQLfaturas2->execute();
    $faturas_clientes = $SQLfaturas2->rowCount();
}
// Notificações
$SQLnoti = "select * from  notificacoes where lido='nao' and usuario_id='" . $_SESSION['usuarioID'] . "'";
$SQLnoti = $conn->prepare($SQLnoti);
$SQLnoti->execute();
$totalnoti = $SQLnoti->rowCount();
// Notificações Contas
$SQLnoti1 = "select * from  notificacoes where lido='nao' and tipo='conta' and usuario_id='" . $_SESSION['usuarioID'] . "'";
$SQLnoti1 = $conn->prepare($SQLnoti1);
$SQLnoti1->execute();
$totalnoti_contas = $SQLnoti1->rowCount();

// Notificações fatura
$SQLnoti2 = "select * from  notificacoes where lido='nao' and tipo='fatura' and usuario_id='" . $_SESSION['usuarioID'] . "'";
$SQLnoti2 = $conn->prepare($SQLnoti2);
$SQLnoti2->execute();
$totalnoti_fatura = $SQLnoti2->rowCount();

if ($usuario['tipo'] == 'revenda') {
    // Notificações Revenda
    $SQLnoti3 = "select * from  notificacoes where lido='nao' and tipo='revenda' and usuario_id='" . $_SESSION['usuarioID'] . "'";
    $SQLnoti3 = $conn->prepare($SQLnoti3);
    $SQLnoti3->execute();
    $totalnoti_revenda = $SQLnoti3->rowCount();

    //Todos os chamados subRevendedores e usuarios do revendedor
    $SQLchamadoscli2 = "select * from  chamados where status='resposta' and id_mestre='" . $_SESSION['usuarioID'] . "'";
    $SQLchamadoscli2 = $conn->prepare($SQLchamadoscli2);
    $SQLchamadoscli2->execute();
    $all_chamados_clientes += $SQLchamadoscli2->rowCount();
    //Todos os chamados subRevendedores e usuarios do revendedor
    $SQLchamadoscli = "select * from  chamados where status='aberto' and id_mestre='" . $_SESSION['usuarioID'] . "'";
    $SQLchamadoscli = $conn->prepare($SQLchamadoscli);
    $SQLchamadoscli->execute();
    $all_chamados_clientes += $SQLchamadoscli->rowCount();

    //subrevendedores
    $SQLsbrevenda = "select * from usuario WHERE id_mestre = '" . $_SESSION['usuarioID'] . "' and subrevenda='sim' ";
    $SQLsbrevenda = $conn->prepare($SQLsbrevenda);
    $SQLsbrevenda->execute();
    $quantidade_sub_revenda = $SQLsbrevenda->rowCount();
}

//Todos os chamados meus 1
$SQLchamados = "select * from  chamados where status='aberto' and usuario_id='" . $_SESSION['usuarioID'] . "'";
$SQLchamados = $conn->prepare($SQLchamados);
$SQLchamados->execute();
$all_chamados += $SQLchamados->rowCount();
//Todos os chamados meus 2
$SQLchamados2 = "select * from  chamados where status='resposta' and usuario_id='" . $_SESSION['usuarioID'] . "'";
$SQLchamados2 = $conn->prepare($SQLchamados2);
$SQLchamados2->execute();
$all_chamados += $SQLchamados2->rowCount();
// Notificações chamados
$SQLnotichama = "select * from  notificacoes where lido='nao' and tipo='chamados' and usuario_id='" . $_SESSION['usuarioID'] . "'";
$SQLnotichama = $conn->prepare($SQLnotichama);
$SQLnotichama->execute();
$totalnoti_chamados = $SQLnotichama->rowCount();
// Notificações Outros
$SQLnoti4 = "select * from  notificacoes where lido='nao' and tipo='outros' and usuario_id='" . $_SESSION['usuarioID'] . "'";
$SQLnoti4 = $conn->prepare($SQLnoti4);
$SQLnoti4->execute();
$totalnoti_outros = $SQLnoti4->rowCount();

if ($usuario['id_mestre'] <> 0) {
    // Notificações users
    $SQLnoti5 = "select * from  notificacoes where lido='nao' and tipo='usuario' and usuario_id='" . $_SESSION['usuarioID'] . "'";
    $SQLnoti5 = $conn->prepare($SQLnoti5);
    $SQLnoti5->execute();
    $totalnoti_users = $SQLnoti5->rowCount();
}


if ($usuario['tipo'] == "revenda") {
    $SQLSub = "select * from usuario WHERE id_mestre = '" . $_SESSION['usuarioID'] . "' and subrevenda='nao'";
    $SQLSub = $conn->prepare($SQLSub);
    $SQLSub->execute();


    if (($SQLSub->rowCount()) > 0) {

        while ($row = $SQLSub->fetch()) {

            $SQLSubSSH = "select * from usuario_ssh WHERE id_usuario = '" . $row['id_usuario'] . "'  ";
            $SQLSubSSH = $conn->prepare($SQLSubSSH);
            $SQLSubSSH->execute();
            $quantidade_ssh += $SQLSubSSH->rowCount();

            $sshsub = $SQLSubSSH->rowCount();

            $SQLUsuario_sshSUSP = "select * from usuario_ssh WHERE id_usuario = '" . $row['id_usuario'] . "' and status='2' and apagar='0' ";
            $SQLUsuario_sshSUSP = $conn->prepare($SQLUsuario_sshSUSP);
            $SQLUsuario_sshSUSP->execute();
            $all_ssh_susp_qtd += $SQLUsuario_sshSUSP->rowCount();

            $SQLAcessoSSH = "SELECT sum(acesso) AS quantidade  FROM usuario_ssh where id_usuario='" . $row['id_usuario'] . "' ";
            $SQLAcessoSSH = $conn->prepare($SQLAcessoSSH);
            $SQLAcessoSSH->execute();
            $SQLAcessoSSH = $SQLAcessoSSH->fetch();
            $total_acesso_ssh += $SQLAcessoSSH['quantidade'];


            $SQLAcessoSSHon = "SELECT sum(online) AS quantidade  FROM usuario_ssh  where id_usuario='" . $row['id_usuario'] . "' ";
            $SQLAcessoSSHon = $conn->prepare($SQLAcessoSSHon);
            $SQLAcessoSSHon->execute();
            $SQLAcessoSSHon = $SQLAcessoSSHon->fetch();
            $total_acesso_ssh_online += $SQLAcessoSSHon['quantidade'];
        }
    }
    $quantidade_sub += $SQLSub->rowCount();


    //Calcula os dias restante
    $data_atual = date("Y-m-d ");
    $data_validade = $usuario['validade'];

    $data1 = new DateTime($data_validade);
    $data2 = new DateTime($data_atual);

    $diferenca = $data1->diff($data2);
    $ano = $diferenca->y * 364;
    $mes = $diferenca->m * 30;
    $dia = $diferenca->d;
    $dias_acesso = $ano + $mes + $dia;

    $quantidade_ssh +=   $quantidade_ssh_sub + $quantidade_ssh_user;

    if ($usuario['ativo'] == 2) {
        echo '<script type="text/javascript">';
        echo 'window.location="pages/suspenso.php";';
        echo '</script>';
        exit;
    }
}

?>
<?php
                        $SQLSubSSH = "SELECT * FROM acesso_servidor where id_usuario='".$usuario['id_usuario']."' ORDER BY id_usuario desc";
                        $SQLSubSSH = $conn->prepare($SQLSubSSH);
                        $SQLSubSSH->execute();
                        if(($SQLSubSSH->rowCount()) > 0){
                        while($row = $SQLSubSSH->fetch()){


                        $buscaserver = "SELECT * FROM servidor where id_servidor='".$row['id_servidor']."'";
                        $buscaserver = $conn->prepare($buscaserver);
                        $buscaserver->execute();
                        $servidor = $buscaserver->fetch();


                        $SQLAcessoSSH = "SELECT sum(acesso) AS quantidade  FROM usuario_ssh where id_servidor = '".$servidor['id_servidor']."'  and id_usuario='".$row['id_usuario']."' ";
                        $SQLAcessoSSH = $conn->prepare($SQLAcessoSSH);
                        $SQLAcessoSSH->execute();
                        $SQLAcessoSSH = $SQLAcessoSSH->fetch();
                        $acessos = $SQLAcessoSSH['quantidade'];
                        if($acessos==0){$acessos=0;}

                        $SQLUsuarioSSH = "SELECT * from usuario_ssh WHERE id_servidor = '".$servidor['id_servidor']."' and id_usuario='".$row['id_usuario']."'";
                        $SQLUsuarioSSH = $conn->prepare($SQLUsuarioSSH);
                        $SQLUsuarioSSH->execute();
                        $contas = $SQLUsuarioSSH->rowCount();
                        if($contas==0){$contas=0;}

                        //Calcula os dias restante
                        $data_atual = date("Y-m-d");
                        $data_validade = $row['validade'];
                        if($data_validade > $data_atual){
                            $data1 = new DateTime( $data_validade );
                            $data2 = new DateTime( $data_atual );
                            $dias_acesso = 0;
                            $diferenca = $data1->diff( $data2 );
                            $ano = $diferenca->y * 364 ;
                            $mes = $diferenca->m * 30;
                            $dia = $diferenca->d;
                            $dias_acesso = $ano + $mes + $dia;

                        }else{
                            $dias_acesso = 0;
                        }

                        $SQLopen = "select * from ovpn WHERE servidor_id = '".$row['id_servidor']."' ";
                        $SQLopen = $conn->prepare($SQLopen);
                        $SQLopen->execute();
                        if($SQLopen->rowCount()>0){
                            $openvpn=$SQLopen->fetch();
                            $texto="<a href='/admin/pages/servidor/baixar_ovpn.php?id=".$openvpn['id']."' class=\"label label-info\">Baixar</a>";
                        }else{
                            $texto="<span class=\"label label-danger\">Indisponivel</span>";
                        }


                        ?>
                        
                            <?php
                            }

                            }


                            ?>


<?php

$SQLV = "SELECT permitir_demo FROM usuario where id_usuario = '" . $_SESSION['usuarioID'] . "'";
$SQLV = $conn->prepare($SQLV);
$SQLV->execute();
$rowv = $SQLV->fetch();
$perm_v2 = $rowv['permitir_demo'];

?>

<?php
 function geraUser(){
				

    $salt = "1234567890";
    srand((double)microtime()*1000000); 

    $i = "";
    $pass = "";
    while($i <= 2){

        $num = rand() % 10;
        $tmp = substr($salt, $num, 1);
        $pass = $pass . $tmp;
        $i++;

    }
    
    
    

    return $pass;

}
$user_ssh = geraUser();
 
?>

<?php
 function geraSenha(){
				

    $salt = "1234567890";
    srand((double)microtime()*1000000); 

    $i = "";
    $pass = "";
    while($i <= 5){

        $num = rand() % 10;
        $tmp = substr($salt, $num, 1);
        $pass = $pass . $tmp;
        $i++;

    }
    
    
    

    return $pass;

}
$senha_ssh = geraSenha();
 
?>
<script>
    $(document).ready(function($) {
        //Initialize Select2 Elements
        $(".select2").select2();
    });
</script>

<!DOCTYPE html>
<html class="loading bordered-layout" lang="pt" data-layout="bordered-layout" data-textdirection="ltr">
<!-- BEGIN: Head-->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="Gerenciador de conexôes SSH">
    <meta name="keywords" content="VPN GESTOR-SSH 🚀, VPN, SSH, Gratis, Registrar">
    <meta name="author" content="Crazy">
    <meta name="msapplication-TileColor" content="#FFFFFF">
    <meta name="theme-color" content="#FFFFFF">
    <title>A.I 🚀 - PAINEL</title>
    <link rel="apple-touch-icon" href="/app-assets/images/ico/favicon.ico">
    <link rel="shortcut icon" type="image/x-icon" href="/app-assets/images/ico/favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;1,400;1,500;1,600" rel="stylesheet">

    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="/app-assets/vendors/css/vendors.min.css">
    <link rel="stylesheet" type="text/css" href="/app-assets/vendors/css/charts/apexcharts.css">
    <link rel="stylesheet" type="text/css" href="/app-assets/vendors/css/extensions/toastr.min.css">
    <link rel="stylesheet" type="text/css" href="/app-assets/vendors/css/tables/datatable/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" type="text/css" href="/app-assets/vendors/css/tables/datatable/responsive.bootstrap5.min.css">


    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="/app-assets/vendors/css/vendors.min.css">
    <link rel="stylesheet" type="text/css" href="/app-assets/vendors/css/tables/datatable/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" type="text/css" href="/app-assets/vendors/css/tables/datatable/responsive.bootstrap5.min.css">
    <link rel="stylesheet" type="text/css" href="/app-assets/vendors/css/tables/datatable/buttons.bootstrap5.min.css">
    <link rel="stylesheet" type="text/css" href="/app-assets/vendors/css/tables/datatable/rowGroup.bootstrap5.min.css">
    <link rel="stylesheet" type="text/css" href="/app-assets/vendors/css/pickers/flatpickr/flatpickr.min.css">
    <link rel="stylesheet" type="text/css" href="/app-assets/vendors/css/forms/select/select2.min.css">
    <!-- END: Vendor CSS-->
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="/app-assets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="/app-assets/css/bootstrap-extended.css">
    <link rel="stylesheet" type="text/css" href="/app-assets/css/colors.css">
    <link rel="stylesheet" type="text/css" href="/app-assets/css/components.css">
    <link rel="stylesheet" type="text/css" href="/app-assets/css/themes/dark-layout.css">
    <link rel="stylesheet" type="text/css" href="/app-assets/css/themes/bordered-layout.css">
    <link rel="stylesheet" type="text/css" href="/app-assets/css/themes/semi-dark-layout.css">

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="/app-assets/css/core/menu/menu-types/vertical-menu.css">
    <link rel="stylesheet" type="text/css" href="/app-assets/css/plugins/charts/chart-apex.css">
    <link rel="stylesheet" type="text/css" href="/app-assets/css/plugins/extensions/ext-component-toastr.css">
    <link rel="stylesheet" type="text/css" href="/app-assets/css/pages/app-invoice-list.css">


    <!-- END: Page CSS-->

    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="/assets/css/style.css">
    <!-- END: Custom CSS-->
    <!--<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>-->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>

</head>
<!-- END: Head-->

<!-- BEGIN: Body-->


    <div class="wrapper">
        <div class="modal fade" id="flaggeral" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true" style="display: none;">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 class="modal-title" id="lineModalLabel">Notificar Geral!</h3>
                    </div>
                    <div class="modal-body">
                        <!-- content goes here -->
                        <form name="editaserver" action="pages/usuario/notificar_home.php" method="post">
                            <div class="form-group">
                                <?php if (($usuario['tipo'] == 'revenda') and ($usuario['subrevenda'] == 'nao')) { ?>
                                    <input type="hidden" class="form-control" id="owner" name="clientes" value="2">
                                <?php } else { ?>
                                    <input type="hidden" class="form-control" id="owner" name="clientes" value="1">
                                <?php } ?>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Mensagem</label>
                                <textarea class="form-control" name="msg" rows="3" cols="20" wrap="off" placeholder="Digite..." require></textarea>
                            </div>

                            <div class="modal-footer">
                                <button class="btn btn-success">Confirmar</button>
                                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancelar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        //paste this code under head tag or in a seperate js file.
        // Wait for window load
        $(window).load(function() {
            // Animate loader off screen
            $(".se-pre-con").fadeOut('slow');;
        });
    </script>
    <script>
        function usuariosonline() {

            // Requisição
            $.post('pages/ssh/online_home.php?requisicao=1',
                function(resposta) {
                    //Adiciona Efeito Fade
                    $("#usuarioson").fadeOut("slow").fadeIn('slow');
                    // Limpa
                    $('#usuarioson').empty();
                    // Exibe
                    $('#usuarioson').append(resposta);
                });
        }
        // Intervalo para cada Chamada
        setInterval("usuariosonline()", 30000);

        // Após carregar a Pagina Primeiro Requisito
        $(function() {
            // Requisita Função acima
            usuariosonline();
        });
    </script>
    <script>
        function atualizar() {
            // Fazendo requisição AJAX
            $.post('pages/ssh/online_home.php?requisicao=2',
                function(online) {
                    // Exibindo frase
                    $('#online_nav').html(online);
                    $('#online').html(online);

                }, 'JSON');
        }
        // Definindo intervalo que a função será chamada
        setInterval("atualizar()", 10000);
        // Quando carregar a página
        $(function() {
            // Faz a primeira atualização
            atualizar();
        });
    </script>

                <?php if ($usuario['tipo'] == "revenda") { ?>
                    <?php if ($usuario['subrevenda'] <> 'sim') { ?>

                    <?php } ?>
                <?php } ?>
                
                
                <?php if (($usuario['tipo'] == "revenda") and ($acesso_servidor > 0)) { ?>


                <?php } ?>
                
                
                <?php if ($usuario['id_mestre'] == 0) { ?>
                    
                <?php } else { ?>
                    
                <?php } ?>

<!-- Input with Icons start -->

<section id="multiple-column-form">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Criar Teste SSH</h4>
                </div>
                <div class="card-body">
                    <form data-toggle="validator" action="../pages/system/conta.ssh.php" method="POST" role="form">
                        <div class="row">
                            <div class="demo-spacing-0 mb-2">
                                <div class="alert alert-warning" role="alert">
                                    <div class="alert-body d-flex align-items-center">
                                        <i data-feather="info" class="me-50"></i>
                                        <span>Esse login será excluído automaticamente, não adianta acrescentar dias posteriormente!!!</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-12">
                                <div class="mb-1">
                                    <label class="form-label" for="basicSelect">Servidor</label>
                                    <div class="input-group input-group-merge">
                                        <span class="input-group-text"><i data-feather="server"></i></span>
                                        <select class="form-select" name="acesso_servidor" id="acesso_servidor">
                                           <?php
                                            $SQLAcesso = "select * from acesso_servidor WHERE id_usuario = '" . $usuario['id_usuario'] . "' ";
                                            $SQLAcesso = $conn->prepare($SQLAcesso);
                                            $SQLAcesso->execute();
                                            if (($SQLAcesso->rowCount()) > 0) {
                                                // output data of each row
                                                while ($row_srv = $SQLAcesso->fetch()) {
                                                    $contas_ssh_criadas = 0;

                                                    $SQLServidor = "select * from servidor WHERE id_servidor = '" . $row_srv['id_servidor'] . "' ";
                                                    $SQLServidor = $conn->prepare($SQLServidor);
                                                    $SQLServidor->execute();
                                                    $servidor = $SQLServidor->fetch();


                                                    $SQLContasSSH = "SELECT sum(acesso) AS quantidade  FROM usuario_ssh where id_servidor = '" . $row_srv['id_servidor'] . "' and id_usuario='" . $_SESSION['usuarioID'] . "' ";
                                                    $SQLContasSSH = $conn->prepare($SQLContasSSH);
                                                    $SQLContasSSH->execute();
                                                    $SQLContasSSH = $SQLContasSSH->fetch();
                                                    $contas_ssh_criadas += $SQLContasSSH['quantidade'];

                                                    $SQLSub = "select * from usuario WHERE id_mestre = '" . $_SESSION['usuarioID'] . "' ";
                                                    $SQLSub = $conn->prepare($SQLSub);
                                                    $SQLSub->execute();

                                                    $resta = $row_srv['qtd'] - $contas_ssh_criadas;

                                            ?>
                                                    <option selected="selected" value="<?php echo $row_srv['id_acesso_servidor']; ?>"> <?php echo $servidor['nome']; ?> Resta <?php echo $resta; ?> de <?php echo $row_srv['qtd']; ?></option>
                                            <?php }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-12">
                                <div class="mb-1">
                                    <label class="form-label" for="basicSelect">Quem será o Dono?</label>
                                    <div class="input-group input-group-merge">
                                        <span class="input-group-text"><i data-feather="users"></i></span>
                                        <select class="form-select" name="usuario" id="usuario">
                                            <option selected="selected" value="<?php echo $_SESSION['usuarioID']; ?>"><?php echo $usuario['login']; ?></option>
                                            <?php
                                            $SQL = "SELECT * FROM usuario where id_mestre = '" . $_SESSION['usuarioID'] . "'";
                                            $SQL = $conn->prepare($SQL);
                                            $SQL->execute();

                                            if (($SQL->rowCount()) > 0) {
                                                // output data of each row
                                                while ($row = $SQL->fetch()) { ?>

                                                    <option value="<?php echo $row['id_usuario']; ?>"><?php echo $row['login']; ?></option>

                                            <?php }
                                            }

                                            ?>
                                        </select>

                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="mb-1">
                                    <label class="form-label" for="basicSelect">Tempo de Duração</label>
                                    <div class="input-group input-group-merge">
                                        <span class="input-group-text"><i data-feather="clock"></i></span>
                                        <select class="form-select" name="tempuser" id="tempuser">
                                            
                                            <option selected="selected" value="60">1 hora <small>(recomendado)</small></option>
                                            
                                        </select>
                                        <input type="hidden" name="dias" id="dias" class="form-control" value="1">
                                        
                                    </div>
                                </div>
                                <input type="hidden" name="acessos" id="acessos" placeholder="1" class="form-control" value="1">
                            </div>

                            <div class="col-md-6 col-12">
                                <div class="mb-1">
                                    <label class="form-label" for="first-name-icon">Usuário</label>
                                    <div class="input-group input-group-merge">
                                        <span class="input-group-text"><i data-feather="user"></i></span>
                                        <input type="text" name="login_ssh" id="login_ssh" class="form-control" data-minlength="4" data-maxlength="32" placeholder="Digite a Senha" required="" value="Teste<?php echo $user_ssh;?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-12">
                                <div class="mb-2">
                                    <label class="form-label" for="country-floating">Senha</label>
                                    <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i data-feather='lock'></i></span>
                                        <input type="text" min="4" max="32" class="form-control" name="senha_ssh" data-minlength="4" id="senha_ssh" placeholder="Digite a Senha" required="" value="<?php echo $senha_ssh;?>">
                                    </div>
                                </div>
                            </div>
                            <?php if ($perm_v2 == 0) { ?>
                                    <input type="hidden" class="form-control" id="tipoconta" name="tipoconta" value="ssh">
                                <?php } else { ?>
                                    <div class="col-12">
                                        <div class="mb-2">
                                            <div class="row custom-options-checkable g-1">
                                                <div class="col-md-6">
                                                    <input class="custom-option-item-check" type="radio" name="tipoconta" id="customOptionsCheckableRadiosWithIcon2" value="ssh" checked />
                                                    <label class="custom-option-item text-center text-center p-1" for="customOptionsCheckableRadiosWithIcon2">
                                                        <i data-feather="shield" class="font-large-1 mb-75"></i>
                                                        <span class="custom-option-item-title h4 d-block">CONTA SSH</span>
                                                        <small>Nesse modo funcionara apenas ssh</small>
                                                    </label>
                                                </div>
                                                <div class="col-md-6">
                                                    <input class="custom-option-item-check" type="radio" name="tipoconta" id="customOptionsCheckableRadiosWithIcon3" value="v2ray" />
                                                    <label class="custom-option-item text-center p-1" for="customOptionsCheckableRadiosWithIcon3">
                                                        <i data-feather="link" class="font-large-1 mb-75"></i>
                                                        <span class="custom-option-item-title h4 d-block">CONTA SSH E V2RAY</span>
                                                        <small>Nesse modo funcionara ssh e v2ray</small>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>
                            <input type="hidden" class="form-control" id="diretorio" name="diretorio" value="/teste-free.php">
                            <input type="hidden" class="form-control" id="owner" name="owner" value="<?php echo $_SESSION['usuarioID']; ?>">

                            <div class="col-12 text-center">
                                <button type="submit" class="btn btn-success me-1 waves-effect waves-float waves-light">Criar</button>
                                <button type="reset" class="btn btn-danger waves-effect">Limpar</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
</section>
<!-- Input with Icons end -->