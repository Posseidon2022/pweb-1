<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8204926466606016"
     crossorigin="anonymous"></script>


<style>
@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap');
</style>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<body style="background:#111;color:#fff;font-size:16px;font-family: 'Roboto', sans-serif;">
<title>WHPLUS</title>
<center>


<img src="./download/whplus.png" style="height:80px;">
<br>
<br>
<style>

/* unvisited link */
a:link {
  color: white;  text-decoration: none;

}

/* visited link */
a:visited {
  color: white;  text-decoration: none;

}
.verbox
{
	    text-align: left;
    border: 1px solid #ccc;
    padding: 5px;
	margin-top:4px;
    font-size: 14px;
}
.notstable
{
	    background: #ff2f00;
    padding: 2px;
    width: max-content;
    border-radius: 4px;
    display: inline-block;
    font-size: 11px;
    font-weight: 800;
    top: -1px;
    position: relative;
}
.stable
{
	    background: green;
    padding: 2px;
    width: max-content;
    border-radius: 4px;
    display: inline-block;
    font-size: 11px;
    font-weight: 800;
    top: -1px;
    position: relative;
}
</style>

<div class="verbox">
<center><h2>Aplicativos Oficiais</h2><center>
<!--<br>
<br>
<center>

<body>

<!<video width="320" height="240" controls="controls" >
<source src="/download/tutorial/tutorial1.mp4" type="video/mp4" />
</video>

</body>
</center>-->
</div>

<div class="verbox">
<center><img src="./download/whon.png" style= width="240" height="180"></center>
<br>
<center>
<video width="200px" loop="true" controls>
<source src="./download/tutorial/on.mp4" type="video/mp4" />
<source src="./download/tutorial/on.mp4" type="video/ogv" />
<source src="./download/tutorial/on.mp4" type="video/webm" />
</video>
</center>
<br>
<center><Small>Atualizado:<br><font color="#FF0000">(28/06/22)</font> </small></center>
<br>
<br>
<center><Small>Basta clicar em baixar aplicativo.</small></center>
<br>
<center>
<a href="https://play.google.com/store/apps/details?id=dutrasystem.gltunnelvpn.whon"><button style="background: #0000FF; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;">Baixar Aplicativo<br>(---Playstore---)</button></a>
</div>


<div class="verbox">
<center><img src="./download/whoficial.png" style= width="240" height="180"></center>
<br>
<center>
<video width="200px" loop="true" controls>
<source src="./download/tutorial/oficial.mp4" type="video/mp4" />
<source src="./download/tutorial/oficial.mp4" type="video/ogv" />
<source src="./download/tutorial/oficial.mp4" type="video/webm" />
</video>
</center>
<br>
<center><Small>Atualizado:<br><font color="#FF0000">(22/06/22)</font> </small></center>
<br>
<center><Small>Basta clicar em baixar aplicativo.</small></center>
<br>
<center>
<a href="/download/whplus.apk"download><button style="background: #0000FF; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;">Baixar Aplicativo</button></a>
</div>


<div class="verbox">
<center><img src="./download/v15.png" style= width="240" height="180"></center>
<br>
<center>
<video width="200px" loop="true" controls>
<source src="./download/tutorial/v15.mp4" type="video/mp4" />
<source src="./download/tutorial/v15.mp4" type="video/ogv" />
<source src="./download/tutorial/v15.mp4" type="video/webm" />
</video>
</center>
<br>
<center><Small>Atualizado:<br><font color="#FF0000">(22/06/22)</font> </small></center>
<br>
<center><Small>Basta clicar em baixar aplicativo.</small></center>
<br>
<center>
<a href="/download/whplus15.apk"download><button style="background: #0000FF; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;">Baixar Aplicativo</button></a>
</div>

<!--<div class="verbox">
<center><img src="./download/y50.png" style= width="240" height="180"></center>
<br>
<center>
<video width="200px" loop="true" controls>
<source src="./tutorial/y50.mp4" type="video/mp4" />
<source src="./download/tutorial/y50.mp4" type="video/ogv" />
<source src="./download/tutorial/y50.mp4" type="video/webm" />
</video>
</center>
<br>
<center><Small>Atualizado:<br><font color="#FF0000">(04/04/22)</font> </small></center>
<br>
<center><Small>Basta clicar em baixar aplicativo.</small></center>
<br>
<center>
<a href="/download/whplus50.apk"download><button style="background: #0000FF; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;">Baixar Aplicativo</button></a>
</div>-->


<div class="verbox">
<center><h2>Arquivos HTTP Injector</h2><center>
<br>
<br>
<center>

<body>

<video width="320" height="240" controls="controls" >
<source src="/download/tutorial/injector.mp4" type="video/mp4" />
<!--Suportado em IE9, Chrome 6 e Safari 5 -->
O seu navegador não suporta a tag vídeo
</video>

</body>
</center>
</div>
<div class="verbox">
<center><img src="./download/imagens/vivo.png" style= width="120" height="90"></center>
<br>
<center><Small>Basta clicar no arquivo que deseja baixar.</small></center>
<br>
<center>
<a href="downloadinjector.php?arquivo=vivo1.ehi"download><button style="background: #0000FF; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;">Baixar Arquivo</button></a>
<!--<a href="downloadinjector.php?arquivo=vivo1r.ehi"download><button style="background: #4B0082; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;">Baixar Arquivo BR2</button></a>-->
<a href="https://play.google.com/store/apps/details?id=com.evozi.injector"><button style="background: #FF0000; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;">Baixar HTTP Injector</button></a>
</div>
<!---------------------------------------------------------------------------------------------------------------------------------->
<!--<div class="verbox">
<center><img src="http://whplus.xyz/download/imagens/claro.png" style= width="120" height="90"></center>
<br>
<br>
<center><Small>Basta clicar no arquivo que deseja baixar.</small></center>
<br>
<center>
<a href="https://play.google.com/store/apps/details?id=xyz.easypro.httpcustom"><button style="background: #FF0000; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;">Baixar HTTP Injector</button></a>
<a href="downloadinjector.php?arquivo=claro1.ehi"download><button style="background: #0000FF; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;">Baixar Arquivo</button></a>
<br>
<br>
<a href="downloadinjector.php?arquivo=claro1r.ehi"download><button style="background: #4B0082; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;">Servidor Reserva</button></a>
</center>
</div>
<br>
<br>-->
<!---------------------------------------------------------------------------------------------------------------------------------->
<div class="verbox">
<center><h2>Arquivos HTTP Custom</h2><center>
<br>
<br>
<center>

<body>

<video width="320" height="240" controls="controls">
<source src="/download/tutorial/tutorial2.mp4" type="video/mp4" />
O seu navegador não suporta a tag vídeo
</video>

</body>
</center>
</div>
<div class="verbox">
<center><img src="./download/imagens/vivo.png" style= width="120" height="90"></center>
<br>
<center><Small>Basta clicar no arquivo que deseja baixar.</small></center>
<br>
<center>
<a href="downloadcustom.php?arquivo=vivo2.hc"download><button style="background: #0000FF; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;">Baixar Arquivo</button></a>
<!--<a href="downloadcustom.php?arquivo=vivo2r.hc"download><button style="background: #4B0082; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;">Baixar Arquivo BR2</button></a>-->
<a href="https://play.google.com/store/apps/details?id=xyz.easypro.httpcustom"><button style="background: #FF0000; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;">Baixar HTTP Custom</button></a>
</center>
</div>
<!---------------------------------------------------------------------------------------------------------------------------------->
<!--<div class="verbox">
<center><img src="https://download.whplus.tk/download/imagens/claro.png" style= width="120" height="90"></center>
<br>
<center><Small>Basta clicar no arquivo que deseja baixar.</small></center>
<br>
<center>
<a href="https://play.google.com/store/apps/details?id=xyz.easypro.httpcustom"><button style="background: #FF0000; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;">Baixar HTTP Custom</button></a>
<a href="downloadcustom.php?arquivo=claro2.hc"download><button style="background: #0000FF; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;">Baixar Arquivo</button></a>
<br>
<br>
<a href="downloadcustom.php?arquivo=claro2r.hc"download><button style="background: #4B0082; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;">Servidor Reserva</button></a>
</center>
</div>-->
<!---------------------------------------------------------------------------------------------------------------------------------->
<!--<div class="verbox">
<center><img src="./download/imagens/tim.png" style= width="120" height="90"></center>
<br>
<center><Small>Basta clicar no arquivo que deseja baixar.</small></center>
<br>
<center>
<a href="downloadcustom.php?arquivo=tim2.hc"download><button style="background: #0000FF; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;">Baixar Arquivo BR1</i></button></a>
<a href="downloadcustom.php?arquivo=tim2r.hc"download><button style="background: #4B0082; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;">Baixar Arquivo BR2</button></a>
<br>
<br>
<a href="https://play.google.com/store/apps/details?id=xyz.easypro.httpcustom"><button style="background: #FF0000; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;">Baixar HTTP Custom</button></a>
</div>-->