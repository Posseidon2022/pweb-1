<?php

$_SG['servidor'] = 'localhost';
// Servidor MySQL
$_SG['usuario'] = 'root';
// Usuário MySQL
$_SG['senha'] = $pass;
// Senha MySQL

$db = mysql_connect($servidor,$usuario,$senha) or die ("não foi possivel conectar com o servidor do banco de dados");

mysql_select_db("ip", $db) or die ("não foi possivel conectar com o banco de dados");

?>