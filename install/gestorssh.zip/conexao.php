<?php

$_SG['servidor'] = 'localhost';
// Servidor MySQL
$_SG['usuario'] = 'root';
// Usuário MySQL
$_SG['senha'] = $pass;
// Senha MySQL
$_SG['banco'] = 'sshplus';
// Banco de dados MySQL

?>