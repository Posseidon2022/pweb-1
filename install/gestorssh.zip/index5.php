
<?php
// do php stuff
//readfile('./anuncio.html');
?>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8204926466606016"
     crossorigin="anonymous"></script>


<style>
@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap');
</style>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<body style="background:#111;color:#fff;font-size:16px;font-family: 'Roboto', sans-serif;">
<title>WHPLUS</title>
<center>



<img src="./download/whplus.png" style="height:120px;">
<br>

<br>
<br>
<div class="verbox">
<a href="./index3.php"><button style="background: #0000FF; border-radius: 6px; padding: 4px; cursor: pointer; color: #fff; border: none; font-size: 16px;"><h4><font color="#FF0000">----------</font>----------<font color="#FF0000">----------</font><h4>Painel Revendedor<h4><font color="#FF0000">----------</font>----------<font color="#FF0000">----------</font><h4></button></a>
<br>
<br>
<a href="./index1.php"><button style="background: #0000FF; border-radius: 6px; padding: 4px; cursor: pointer; color: #fff; border: none; font-size: 16px;"><h4><font color="#FF0000">----------</font>----------<font color="#FF0000">----------</font><h4>Download SSH<h4><font color="#FF0000">----------</font>----------<font color="#FF0000">----------</font><h4></button></a>
<br>
<br>
<a href="./index2.php"><button style="background: #0000FF; border-radius: 6px; padding: 4px; cursor: pointer; color: #fff; border: none; font-size: 16px;"><h4><font color="#FF0000">----------</font>----------<font color="#FF0000">----------</font><h4>Download IPTV<h4><font color="#FF0000">----------</font>----------<font color="#FF0000">----------</font><h4></button></a>
</div>
<!--<br>
<br>
<a href="./index4.php"><button style="background: #0000FF; border-radius: 6px; padding: 4px; cursor: pointer; color: #fff; border: none; font-size: 16px;"><h4><font color="#FF0000">----------</font>----------<font color="#FF0000">----------</font><h4>Cinema<h4><font color="#FF0000">----------</font>----------<font color="#FF0000">----------</font><h4></button></a>-->
<style>