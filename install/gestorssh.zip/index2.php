
<!---/download/whplus.apk---->
<?php
// do php stuff
//readfile('./download/menu.php');
?>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8204926466606016"
     crossorigin="anonymous"></script>


<style>
@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap');
</style>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<body style="background:#111;color:#fff;font-size:16px;font-family: 'Roboto', sans-serif;">
<title>WHPLUS</title>
<center>


<img src="./download/whplus.png" style="height:80px;">
<br>
<br>
<style>

/* unvisited link */
a:link {
  color: white;  text-decoration: none;

}

/* visited link */
a:visited {
  color: white;  text-decoration: none;

}
.verbox
{
	    text-align: left;
    border: 1px solid #ccc;
    padding: 5px;
	margin-top:4px;
    font-size: 14px;
}
.notstable
{
	    background: #ff2f00;
    padding: 2px;
    width: max-content;
    border-radius: 4px;
    display: inline-block;
    font-size: 11px;
    font-weight: 800;
    top: -1px;
    position: relative;
}
.stable
{
	    background: green;
    padding: 2px;
    width: max-content;
    border-radius: 4px;
    display: inline-block;
    font-size: 11px;
    font-weight: 800;
    top: -1px;
    position: relative;
}
</style>
<!--<p><button style="background: #00cc00; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;"><?php $url = file_get_contents('http://209.14.136.236:8888/server/online'); echo $url ?> Onlines</button></p>-->
<!--<center><iframe src="http://209.14.136.236:8181/server/" name="conteudo"width="150" height="80" border="0" frameborder="0"></iframe></center>-->
<div class="verbox">
<center><h2>Aplicativos P2Blade</h2><center>
<br>
<br>
</div>
<div class="verbox">
<center><h2>Aplicativo 1</h2><center>
<center><Small>Basta clicar no arquivo que deseja baixar.</small></center>
<br>
<center>
<a href="./download/p2blade.apk"download><button style="background: #0000FF; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;">Baixar</button></a>
</div>
<br>
<br>
<!---------------------------------------------------------------------------------------------------------------------------------->
<div class="verbox">
<center><h2>Aplicativos NTVBR</h2><center>
<br>
<br>
</div>
<div class="verbox">
<br>
<center><h2>Aplicativo 1</h2><center>
<center><Small>Basta clicar no arquivo que deseja baixar.</small></center>
<br>
<center>
<a href="./download/ntvbr.apk"download><button style="background: #0000FF; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;">Baixar</button></a>
</center>
</div>