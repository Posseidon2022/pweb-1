<?php


session_start();


$expira_em  = 5; //DEFINE EM MINUTOS A EXPIRAÇÃO DO ACESSO DO USUARIO


$sessao     = session_id();


$ip         = $_SERVER['REMOTE_ADDR'];


$tempo_on   = date('Y-m-d H:i:s');


$tempo_fim  = date('Y-m-d H:i:s',mktime(date('H'),date('i') - $expira_em,date('s'),date('m'),date('d'),date('Y')));





$conexao = mysql_connect('localhost','root','ww27012001') or die("Erro ao conectar");


$db = mysql_select_db('whpluss_contador') or die("Erro ao selecionar o DB");





//EXCLUI USUARIOS QUE ESTEJAM INATIVOS NO TEMPO DEFINIDO COMO EXPIRAÇÃO


mysql_query("DELETE FROM usuarios_online WHERE tempo <= '$tempo_fim'");





//SELECIONA USUARIO


$sql = mysql_query("SELECT id FROM usuarios_online WHERE sessao='$sessao'");


$total = mysql_num_rows($sql);


if($total){


 mysql_query("UPDATE usuarios_online SET tempo='$tempo_on' WHERE sessao='$sessao'");


}else{


 mysql_query("INSERT INTO usuarios_online(sessao,tempo,ip)VALUES('$sessao','$tempo_on','$ip')");


 $sql_c = mysql_query("SELECT id FROM contador");


 $total_c = mysql_num_rows($sql_c);


 if($total_c){


   mysql_query("UPDATE contador SET visitas=visitas+1");


 }else{


   mysql_query("INSERT INTO contador(visitas)VALUES(1)");


 }


}


//ONLINES


$sql_o = mysql_query("SELECT id FROM usuarios_online");


$total_online = mysql_num_rows($sql_o);


//VISITAS


$sql_v = mysql_query("SELECT visitas FROM contador LIMIT 1");


$d_v = mysql_fetch_object($sql_v);


$total_visitas = $d_v->visitas;

?>
<?php
// do php stuff
readfile('./anuncio.html');
?>
<style>
@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap');
</style>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<body style="background:#111;color:#fff;font-size:16px;font-family: 'Roboto', sans-serif;">
<title>WHPLUS</title>
<center>
<img src="./download/whplus.png" style="height:110px;"> <br><br>
<p><button style="background: #00cc00; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;"><?php  echo $total_online; ?> Total Onlines</button></p>
<p><button style="background: #ff0000; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;"><?php  echo $total_visitas; ?> Total Visitas</button></p>
<br>
<br>
<style>

/* unvisited link */
a:link {
  color: white;  text-decoration: none;

}

/* visited link */
a:visited {
  color: white;  text-decoration: none;

}
.verbox
{
	    text-align: left;
    border: 1px solid #ccc;
    padding: 5px;
	margin-top:4px;
    font-size: 14px;
}
.notstable
{
	  background: #ff2f00;
    padding: 2px;
    width: max-content;
    border-radius: 4px;
    display: inline-block;
    font-size: 11px;
    font-weight: 800;
    top: -1px;
    position: relative;
}
.stable
{
	  background: green;
    padding: 2px;
    width: max-content;
    border-radius: 4px;
    display: inline-block;
    font-size: 11px;
    font-weight: 800;
    top: -1px;
    position: relative;
}
</style>
<div class="verbox">
<center><h2>Homem-Aranha: Sem Volta para Casa</h2><center>
<br>
<br>
<center>

<body>

<video width="320" height="240" controls="controls" autoplay="autoplay">
<source src="./download/filme12.mp4" type="video/mp4" />
<!--Suportado em IE9, Chrome 6 e Safari 5 -->
O seu navegador não suporta a tag vídeo
</video>

</body>
</center>
<br>
<br>
<center><img src="https://i.imgur.com/yjdLt9l.png" style= width="120" height="190"></center>
<br>
<center><Small>Basta clicar no arquivo que deseja baixar.</small></center>
<br>
<center>
<a href="./download/filme12.mp4"download><button style="background: #0000FF; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;">Baixar Filme</button></a>
</div>
<!---------------------------------------------------------------------------------------------------------------------------------->
<br>
<br>
<!---------------------------------------------------------------------------------------------------------------------------------->
<div class="verbox">
<center><h2>Viuva Negra</h2><center>
<br>
<br>
<center>

<body>

<video width="320" height="240" controls="controls" autoplay="autoplay">
<source src="./download/filme2.mp4" type="video/mp4" />
<!--Suportado em IE9, Chrome 6 e Safari 5 -->
O seu navegador não suporta a tag vídeo
</video>

</body>
</center>
<br>
<br>
<center><img src="https://cdn.shortpixel.ai/client/to_webp,q_glossy,ret_img,w_250/https://comandotorrentshds.org/wp-content/uploads/2021/07/Viuva-Negra-Torrents.jpg" style= width="120" height="190"></center>
<br>
<center><Small>Basta clicar no arquivo que deseja baixar.</small></center>
<br>
<center>
<a href="filme2.mp4"download><button style="background: #FF0000; border-radius: 6px; padding: 5px; cursor: pointer; color: #fff; border: none; font-size: 16px;">Baixar Filme</button></a>
</center>
</div>
<!----------------------------------------------------------------------------------------------------------------------------------